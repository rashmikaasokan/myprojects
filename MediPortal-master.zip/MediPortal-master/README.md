# MediPortal
( ͡° ͜ʖ ͡°)    Web Technologies Project -> MediPortal -> Section -F   ( ͡° ͜ʖ ͡°)
