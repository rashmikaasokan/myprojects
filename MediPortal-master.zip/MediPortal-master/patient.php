<!DOCTYPE>
<html>
<head>
	<title>Home - MediPortal</title>
</head>
<body>
	
	<div align="center">
                             <td width="70%" align="center" valign="top">

                                <h1 align="center">Patient Details</h1>
                                <div>
                                        <h1>Bob</h1>
                                            <table width="100%">
                                                <tr>
                                                    <td width="60%">
                                                        <table width="100%">
                                                            <tr>
                                                                <td>
                                                                    <table width="100%">
                                                                        <td width="10%">&nbsp;</td>
                                                                        <td width="30%"><strong>Name</strong></td>
                                                                        <td><strong>:</strong></td>
                                                                        <td>Bob Pirate </td>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                            <tr><td><hr/></td></tr>
                                                            
                                                           
                                                            <tr>
                                                                <td>
                                                                    <table width="100%">
                                                                        <td width="10%">&nbsp;</td>
                                                                        <td width="30%"><strong>Gender</strong></td>
                                                                        <td><strong>:</strong></td>
                                                                        <td>Male</td>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                            <tr><td><hr/></td></tr>
                                                            <tr>
                                                                <td>
                                                                    <table width="100%">
                                                                        <td width="10%">&nbsp;</td>
                                                                        <td width="30%"><strong>Email</strong></td>
                                                                        <td><strong>:</strong></td>
                                                                        <td>Bob@example.com</td>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                            <tr><td><hr/></td></tr>
                                                            <tr>
                                                                <td>
                                                                    <table width="100%">
                                                                        <td width="10%">&nbsp;</td>
                                                                        <td width="30%"><strong>Phone</strong></td>
                                                                        <td><strong>:</strong></td>
                                                                        <td>01700000000</td>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                            <tr><td><hr/></td></tr>
                                                            <tr>
                                                                <td>
                                                                    <table width="100%">
                                                                        <td width="10%">&nbsp;</td>
                                                                        <td width="30%"><strong>Date of Birth</strong></td>
                                                                        <td><strong>:</strong></td>
                                                                        <td>19/9/1998</td>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                            <tr><td><hr/></td></tr>
                                                            <tr>
                                                                <td>
                                                                    <table width="100%">
                                                                        <td width="10%">&nbsp;</td>
                                                                        <td width="30%"><strong>Country</strong></td>
                                                                        <td><strong>:</strong></td>
                                                                        <td>Bangladesh</td>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                            <tr><td><hr/></td></tr>
                                                            <tr>
                                                    <td>
                                                        <table width="100%">
                                                            <td width="30%"><strong>Blood Donation</strong></td>
                                                            <td><strong>:</strong></td>
                                                            <td>
                                                                <fieldset>
                                                                    <table>
                                                                        <tr>
                                                                            <td>Blood Group</td>
                                                                            <td>:</td>
                                                                            <td>A+</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Weight</td>
                                                                            <td>:</td>
                                                                            <td>Over 50 Kg</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Heart Condition</td>
                                                                            <td>:</td>
                                                                            <td>Good</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Injected Drugs</td>
                                                                            <td>:</td>
                                                                            <td>No</td>
                                                                        </tr>
                                                                    </table>
                                                                </fieldset>
                                                            </td>
                                                        </table>
                                                    </td>
                                                </tr>
                                                            <tr><td><hr/></td></tr>
                                                           
                                                        </table>
                                                    </td>
                                                    <td width="40%">
                                                        <table align="center">
                                                            <tr>
                                                                <td align="center"><img src="images/usericon.png"/></td>
                                                            </tr>
                                                            
                                                        </table>
                                                    </td>
                                                </tr>
                                               <script type="text/javascript">
                                                    function goBack(){
                                                        window.history.back();
                                                    }
                                                </script>
                                                <tr>
                                                    <td align="center">
                                                        <button onclick="goBack()">Go Back</button> 
                                                    </td>
                                                </tr>
                                            </table>
                                    </div>

                                
                            </td>
                        </div>
                    </table>
                </div>
            </td>
        </tr>
        <tr>
            <td>


            	<div>
                	<table align="center">
						<tr align="center">
							<td>
							<a href="https://www.facebook.com/">
							<img src="images/facebook.png">
			                 </a>
			             </td>
							<td>
									<a href="https://www.twitter.com/">
									<img src="images/twitter.png">
								</a>
							</td>
						</tr>
					</table>
                    <table align="center">
                        <td>&copy;2017 MediPortal. All rights reserved.</td>
                    </table>
                </div>
            </td>
        </tr>
    </table>
</body>

</html>
