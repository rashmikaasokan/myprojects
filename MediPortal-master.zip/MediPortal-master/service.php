<!DOCTYPE>
<html>
<head>
	<title>Home - MediPortal</title>
</head>
<body>
	<table>
		<div>
		<div>
				<table align="center" width="100%">
					<tr align="right">
						<td width="10%">
							<a href="Home.php"><img src="images/logo.png" align="left"></a>
						</td>
						<td width="30%">&nbsp;</td>
						<td align="center" width="10%">
							<fieldset><a href="Home.php" >Home <img src="images/home.png"></a></fieldset>
						</td>
						<td width="10%" align="center">
							<fieldset><a href="Registration.php">Registration<img src="images/registration.png"></a></fieldset>
						</td>
						<td width="10%" align="center">
							<fieldset><a href="service.php">Our Service<img src="images/service.png"></a></fieldset>
						</td>
						<td width="10%" align="center">
							<fieldset><a href="Login.php">Login<img src="images/login.png"></a></fieldset>
						</td>
					</tr>
				</table>
		</div>

		<div>
			<img src="images/serviceimage.png" width="100%" height="70%">
		</div>
                  <fieldset>                   <div>
                   	<h1 align="center"><b>Our Service</b></h1>
                   </div>
               </div>
		<div>
					<table align="left" width="35%">
						<tr>
							<td align="center">
								<fieldset>
									<a href="appointment.php"><img src="images/appointment.png" align="center" width="30%"></a>
									<h1>Get Appointment From Home</h1>
									<hr>
									<p>
										Find your doctor and get an appointment today.
										       Now You can find your choosable doctor at home and get an appointment by staying at home.
									</p>
								</fieldset>
							</td>
						</tr>
					</table>
				
					<table align="right" width="30%">
						<tr>
							<td align="center">
								<fieldset>
									<img src="images/donar.png" width="30%" align="center">
									<h1>Search for a blood donors</h1>
									<hr>
									<p>
										Find a donor and get an appointment today.

										      In Emergency Cases now you donot face any problem for blood. We inform you available blood donar at 24 hours. You now find blood donar in your own area easily.
									</p>
								</fieldset>
							</td>
						</tr>
					</table>
				</div>


                   <div>
				<table align="right" width="35%">
						<tr>
							<td align="center">
								<fieldset>
									<img src="images/contact.png" width="30%" align="center">
									<h1>Contact with your doctor</h1>
									<hr>
									<p>
										With e-consultation you can talk to your doctor from home or anywhere.

										We are care about your advantage. We provide you to consult with a doctor stay at home. Now you can be connected with a doctor at any time from anywhere
									</p>
								</fieldset>
							</td>
						</tr>
					</table>
				</div>
			</fieldset>

<br><br><br><br><br><br><br><br>


			
<br><br>
<div align="center">

	<i><b>Follow Us In</b></i>
		<table align="center">
			<tr align="center">
				<td>
				<a href="https://www.facebook.com/">
				<img src="images/facebook.png">
                 </a>
             </td>
				<td>
						<a href="https://www.twitter.com/">
						<img src="images/twitter.png">
					</a>
				</td>
			</tr>
		</table>
		
		<table align="center">
			<tr>
				<td align="center" colspan="3">
				<a href="About_Us.php">About Us   </a>
		
			</td>
			<td align="center" colspan="3">
				<a href="Contact_Us.php">Contact Us   </a>
			</td>
			<td align="center" colspan="3">
				<a href="privacyPolicy.php">Privacy Policy   </a>
			</td>
			<td align="center" colspan="3">
				<a href="faq.php">FAQ</a>
			</td>
			</tr>
		</table>
	</div>
    <div>
<table align="center" width="100%" border="1">
<tr>
<td align="center" colspan="3">
<b>&copy;2017 MediPortal. All rights reserved</b>
</td>
</tr>
</table>
</div>
</body>
</html>
